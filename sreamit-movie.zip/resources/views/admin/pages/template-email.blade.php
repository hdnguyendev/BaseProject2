
    <h1>{{ $mailData['title'] }}</h1>
    @php
        echo $mailData['body']
    @endphp
