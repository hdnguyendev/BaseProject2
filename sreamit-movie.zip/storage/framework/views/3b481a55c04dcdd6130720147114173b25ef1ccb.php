
    <h1><?php echo e($mailData['title']); ?></h1>
    <p><?php echo e($mailData['body']); ?></p>
<?php /**PATH C:\Users\dangn\Desktop\sreamit-movie\resources\views/admin/pages/email.blade.php ENDPATH**/ ?>