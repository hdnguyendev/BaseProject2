<?php $__env->startSection('main_content'); ?>
    <!-- MAIN CONTENT-->

    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="col-md-12">

                <h3 class="title-5 m-b-35">Client table</h3>

                <div class="table-responsive table-responsive-data2">
                    <table class="table table-data2">

                        <thead>
                            <tr>
                                <th>no.</th>
                                <th>name</th>
                                <th>email</th>
                                <th>username</th>
                                
                                <th>avatar</th>
                                <th>status</th>
                                <th style="text-align: center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($data): ?>
                                <?php
                                    $d = 0;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $d += 1;
                                    ?>
                                    <tr class="tr-shadow">
                                        <td style="vertical-align: middle !important"><?php echo e($d); ?></td>
                                        <td><?php echo e($item->client_name); ?></td>
                                        <td>
                                            <span class="block-email"><?php echo e($item->client_email); ?></span>
                                        </td>
                                        <td><?php echo e($item->client_username); ?></td>
                                        <td><img width=50px height=50px
                                                src="<?php echo e(asset('upload/avatars/' . $item->client_avatar)); ?>" alt="">
                                        </td>
                                        <?php if($item->client_status): ?>
                                            <td><span class="status--process">Active</span></td>
                                        <?php else: ?>
                                            <td><span class="status--denied">Ban</span></td>
                                        <?php endif; ?>

                                        <td>
                                            <div class="table-data-feature">
                                                <a href="<?php echo e(route('send_mail', ['id' => $item->client_id])); ?>">
                                                    <button class="item" data-toggle="tooltip" data-placement="top"
                                                        title="" data-original-title="Send">
                                                        <i class="zmdi zmdi-mail-send"></i>
                                                    </button>
                                                </a>
                                                <button class="item" data-toggle="tooltip" data-placement="top"
                                                    title="" data-original-title="Edit">
                                                    <i class="zmdi zmdi-edit"></i>
                                                </button>
                                                <?php if($item->client_status): ?>
                                                    <a href="<?php echo e(route('ban_client', ['id' => $item->client_id])); ?>">
                                                        <button class="item" data-toggle="tooltip" data-placement="top"
                                                            title="" data-original-title="Ban">
                                                            <i class="zmdi zmdi-block"></i>
                                                        </button>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('unban_client', ['id' => $item->client_id])); ?>">
                                                        <button class="item" data-toggle="tooltip" data-placement="top"
                                                            title="" data-original-title="Unban">
                                                            <i class="zmdi zmdi-star"></i>
                                                        </button>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>

                    </table>


                </div>


            </div>
            

        </div>

    </div>

    <script></script>
    <!-- END MAIN CONTENT-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dangn\Desktop\sreamit-movie\resources\views/admin/pages/clients.blade.php ENDPATH**/ ?>