<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            
                            <h1>Login with Administrator</h1>
                        </div>
                        <?php
                            $message = Session::get('message');
                            if ($message) {

                                echo "<div style='color: red; text-align:center'>$message</div>";
                                Session::put('message',null);
                            }
                        ?>
                        <div class="login-form">
                            <form action="<?php echo e(URL::to('admin/login_handle')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="au-input au-input--full" type="text" name="username" required
                                        placeholder="Enter your username ...">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password" required
                                        placeholder="Enter your password ... ">
                                </div>

                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                                
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dangn\Desktop\sreamit-movie\resources\views/admin/login.blade.php ENDPATH**/ ?>