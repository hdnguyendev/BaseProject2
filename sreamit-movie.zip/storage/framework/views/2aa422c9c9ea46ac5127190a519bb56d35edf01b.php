
    <h1><?php echo e($mailData['title']); ?></h1>
    <?php
        echo $mailData['body']
    ?>
<?php /**PATH C:\Users\dangn\Desktop\sreamit-movie\resources\views/admin/pages/template-email.blade.php ENDPATH**/ ?>